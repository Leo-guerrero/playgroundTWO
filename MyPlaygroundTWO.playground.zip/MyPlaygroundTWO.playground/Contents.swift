import UIKit

var greeting = "Hello, playground"

var x : Int? = 32

print(x!)


func yearalbumreleased(Name: String) -> Int? {
    
    if (Name == "red"){
        return 2012
    }
    
    if (Name == "1989") {
        return 2014
    }
    
    if (Name == "Taylor Swift"){
        return 2006
    }
    
    if (Name == "Speak Now"){
        return 2010
    }
    
    if(Name == "Lover"){
        return 2019
    }
    
    if (Name == "Kanye Better"){
        return 808
    }
    
    return nil
}


//optional wrapping

if let year = yearalbumreleased(Name: "red"){
    print("It was released in \(year)")
}
else {
    print("Dosen't exist lil bro 😹")
}


let releasedyear = yearalbumreleased(Name: "1989")

if releasedyear == nil{
    print("Album don't exist ya bum")
}
else{
    print("Album released \(releasedyear!)")
}

//Optional Chaining "?"

func albumreleased(albumYear: Int) -> String?{
    switch albumYear {
    case 2006: return "Taylor Swift"
    case 2014: return "1989"
    case 2019: return "Lover"
    case 2010: return "Speak Now"
    case 2012: return "red"
    default: return nil
    }
}

let yearreleased = albumreleased(albumYear: 2010)?.uppercased()

//the nil coalescing operator "??"

let albumYear = albumreleased(albumYear: 3010)?.uppercased() ?? "unknown or whatever"

print("the album is \(albumYear)")
